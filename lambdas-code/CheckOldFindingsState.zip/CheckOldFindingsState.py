import json
import boto3
from datetime import datetime, date
import logging
import os

logger = logging.getLogger(__name__)
securityhub = boto3.client('securityhub')
dynamo = boto3.client('dynamodb')

def lambda_handler(event, context):
    print(json.dumps(event))
    try:
        Table_Name = os.environ['dynamodb_tablename']
        Resource = event['Added_Item']['Item']['Resource']['S']
        Title = event['Added_Item']['Item']['Title']['S']
    except Exception as e:
        logger.info("Error when loading variables from event", e)
    
    try:
        get_item = get_dynamodb_item(Table_Name,Resource,Title)
        Resource = get_item['Item']['Resource']['S']
        Title = get_item['Item']['Title']['S']
    except Exception as e:
        logger.info("Error when getting item from dynamodb table", e)
    
    try:
        securityhub_finding = check_securityhub_finding_state(Resource,Title)
        finding_state = securityhub_finding[0]
        securityhub_first_observed_at = securityhub_finding[1]
    except Exception as e:
        logger.info("Error when checking finding state in security hub", e)

    try:
        days_of_difference = calculate_days_of_difference(securityhub_first_observed_at)
    except Exception as e:
        logger.info("Error when calculating days of difference between dates", e)

    try:
        send_to_operations = False
        if int(days_of_difference) > 15:
            send_to_operations = True
            return { 
                'Finding' : Resource,
                'Title' : Title,
                'State' : finding_state,
                'SendToOperations' : str(send_to_operations),
                'Event' : event['Event']
            }
        else:
            return { 
                'Finding' : Resource,
                'Title' : Title,
                'State' : finding_state,
                'SendToOperations' : str(send_to_operations),
                'Event' : event['Event']
            }
    except Exception as e:
        logger.info("Error when returning finding state", e)
        

def get_dynamodb_item(Table_Name,Resource,Title):
    get_table_item = dynamo.get_item(
        TableName=Table_Name,
        Key={
            'Resource': {'S': Resource},
            'Title': {'S': Title}
        }
    )
    return get_table_item

def check_securityhub_finding_state(Resource,Title):
    findings = securityhub.get_findings(
        Filters={
            'ResourceId': [
                {
                    'Value': Resource,
                    'Comparison': 'EQUALS'
                },
            ],
            'Title': [
                {
                    'Value': Title,
                    'Comparison': 'EQUALS'
                }
            ]
        }
    )
    State = findings['Findings'][0]['Workflow']['Status']
    FirstObservedAt = findings['Findings'][0]['FirstObservedAt']
    return State, FirstObservedAt

def calculate_days_of_difference(securityhub_first_observed_at):
    first_time_observed = securityhub_first_observed_at.split('.')[0].split('T')[0]
    today_datetime = str(date.today().strftime("%Y-%m-%d")).split('.')[0].split('T')[0]
    if today_datetime == first_time_observed:
        days_of_difference = '0'
    else:
        time_difference = datetime.strptime(today_datetime, "%Y-%m-%d") - datetime.strptime(first_time_observed, "%Y-%m-%d")
        days_of_difference = str(time_difference).split(' ')[0]
    return days_of_difference