import boto3
import json
import logging
import os

logger = logging.getLogger(__name__)

def lambda_handler(event, context):
    try:
        region= event['Event']['region']
        description = event['Event']['detail']['findings'][0]['Description']
        compliance_status = 'FAILED'
        severity = event['Event']['detail']['findings'][0]['Severity']['Label']
        product_name = event['Event']['detail']['findings'][0]['ProductName']
        if product_name == 'GuardDuty':
            remediation_text = ''
        else:
            remediation_text = event['Event']['detail']['findings'][0]['Remediation']['Recommendation']['Text']
        print(remediation_text)
        if product_name == 'Security Hub':
            remediation_url = event['Event']['detail']['findings'][0]['Remediation']['Recommendation']['Url']
        else:
            remediation_url = ''
        print(remediation_url)
        accountid = event['Event']['detail']['findings'][0]['AwsAccountId']
        print(accountid)
        resources = event['Event']['detail']['findings'][0]['Resources'][0]['Id']
        print(resources)
        ses_emails_sender = os.environ['ses_emails_sender']
        ses_emails_recipients = json.loads(os.environ['ses_emails_recipients']).values()
        email_list = []
        for email in ses_emails_recipients:
            email_list.append(email)
    except Exception as e:
        logger.info("Error when loading variables from event", e)
        
    try:
        send_email(region,description,compliance_status,severity,remediation_text,remediation_url,accountid,resources,ses_emails_sender,email_list)
    except Exception as e:
        logger.info("Error when sending email", e)

def send_email(region,description,compliance_status,severity,remediation_text,remediation_url,accountid,resources,ses_emails_sender,email_list):
    SENDER = ses_emails_sender
    RECIPIENT = email_list
    SUBJECT = '[Security Hub] - A security alert has been logged on the account ' + accountid    
    CHARSET = 'UTF-8'

    BODY_HTML = """
    <html>
    <head></head>
    <body>
      <p><br><b>- Account ID:</b> {accountid}</br>
      <p><br><b>- Region:</b> {region}</br>
      <p><br><b>- Description:</b> {description}</br>
      <p><br><b>- Compliance Status:</b> {compliance_status}</br>
      <p><br><b>- Severity:</b> {severity}</br>
      <p><br><b>- Resources:</b> {resources}</br>
      <p><br><b>- Remediation:</b> {remediation_text} - {remediation_url}</br>
    </body>
    </html>
    """

    NEW_BODY_HTML = BODY_HTML.format(accountid=accountid,region=region,description=description,compliance_status=compliance_status,severity=severity,resources=resources,remediation_text=remediation_text,remediation_url=remediation_url)

    
    client = boto3.client('ses',region_name=region)
    
    for mail in RECIPIENT:
        try:
            response = client.send_email(
                Destination={
                    'ToAddresses': [
                        mail,
                    ],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': CHARSET,
                            'Data': NEW_BODY_HTML,
                        },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                        },
                    },
                Source=SENDER,
            )
        except Exception as e:
            logger.info("Error when sending email", e)
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])