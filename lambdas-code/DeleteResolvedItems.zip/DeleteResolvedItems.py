import json
import boto3
from datetime import datetime, date
import logging
import os

logger = logging.getLogger(__name__)
securityhub = boto3.client('securityhub')
dynamo = boto3.client('dynamodb')

def lambda_handler(event, context):
    try:
        Table_Name = os.environ['dynamodb_tablename']
    except Exception as e:
        logger.info("Error when loading variables from event", e)
    
    try:
        dynamodb_table_items = get_dynamodb_items(Table_Name)
    except Exception as e:
        logger.info("Error when getting items from dynamodb table", e)
        
        for item in dynamodb_table_items:
            Resource = item['Resource']
            Title = item['Title']
            try:
                check_finding_state = check_securityhub_finding_state(Resource,Title)
                finding_state = check_finding_state[0]
                record_state = check_finding_state[1]
            except Exception as e:
                logger.info("Error when checking finding state in security hub", e)
        
            try:
                if finding_state != 'NEW' or record_state != 'ACTIVE':
                    dynamodb = boto3.resource('dynamodb')
                    table = dynamodb.Table(Table_Name)
                    table.delete_item(
                        Key={
                            "Resource": Resource,
                            "Title": Title
                        }
                    )
                    return { 
                        'Resource' : Resource,
                        'Title' : Title,
                        'State' : 'ITEM DELETED FROM DYNAMODB'
                    }
                else:
                    return { 
                        'Resource' : Resource,
                        'Title' : Title,
                        'State' : 'FINDING STILL ACTIVE IN SECURITY HUB'
                    }
            except Exception as e:
                logger.info("Error when deleting dynamodb item", e)

def get_dynamodb_items(Table_Name):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(Table_Name)
    response = table.scan()
    data = response['Items']
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
    return data

def check_securityhub_finding_state(Resource,Title):
    resource_key = 'Resource[0]'
    title_key = 'Title'
    findings = securityhub.get_findings(
        Filters={
            resource_key: [
                {
                    'Key': 'Id',
                    'Value': Resource,
                    'Comparison': 'EQUALS'
                },
            ],
            title_key: [
                {
                    'Value': Title,
                    'Comparison': 'EQUALS'
                }
            ]
        }
    )
    State = findings['Findings'][0]['Workflow']['Status']
    RecordState = findings['Findings'][0]['RecordState']
    return State, RecordState