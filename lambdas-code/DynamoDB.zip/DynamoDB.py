import json
import boto3
import logging
import os

logger = logging.getLogger(__name__)
dynamo = boto3.client('dynamodb')

def lambda_handler(event, context):
    print(json.dumps(event))
    
    Table_Name = os.environ['dynamodb_tablename']
    for finding in event['detail']['findings']:
        try:
            event_details = get_event_details(finding)
            Compliance = event_details[0]
            Severity = event_details[1]
            Title = event_details[2]
            WorkflowStatus = event_details[3]
            Resource = event_details[4]
            FirstTimeObserved = event_details[5]
        except Exception as e:
            logger.info("Error when loading variables from event", e)
            
        try:
            get_item = get_dynamodb_item(Table_Name,Resource,Title)
        except Exception as e:
            logger.info("Error when getting item from dynamodb table", e)

        try:    
            if str(get_item).find('Item') > 0:
                message = 'Item encontrado en la tabla, no hago nada'
                return { 
                    'Added_Item' : get_item,
                    'Message' : message,
                    'Event' : event
                }
            else:
                response = dynamo.put_item(
                    TableName=Table_Name,
                    Item={
                        'Resource': {'S': Resource},
                        'WorkflowStatus': {'S': WorkflowStatus},
                        'Severity': {'S': Severity},
                        'Compliance': {'S': Compliance},
                        'Title':{'S': Title} ,
                        'FirstTimeObserved':{'S': FirstTimeObserved} 
                    }
                )
                get_item = get_dynamodb_item(Table_Name,Resource,Title)
                if str(get_item).find('Item') > 0:
                    message = 'Item added to DynamoDB Table'
                    return { 
                        'Added_Item' : get_item,
                        'Message' : message,
                        'Event' : event
                    }
                else:
                    message = 'Error when adding the item'
                    return { 
                        'Added_Item' : get_item,
                        'Message' : message,
                        'Event' : event
                    }
        except Exception as e:
            logger.info("Error when checking item in dynamodb table", e)

def get_event_details(finding):
    product_name = finding['ProductName']
    if product_name == 'Security Hub':
        Compliance = finding['Compliance']['Status']
    else:
        Compliance = 'FAILED'
    Severity = finding['FindingProviderFields']['Severity']['Label']
    Title = finding['Title']
    WorkflowStatus = finding['Workflow']['Status']
    Resource = finding['Resources'][0]['Id']
    if product_name == 'Systems Manager Patch Manager':
        FirstTimeObserved = finding['CreatedAt']
    else:
        FirstTimeObserved = finding['FirstObservedAt']
    return Compliance,Severity,Title,WorkflowStatus,Resource,FirstTimeObserved
    
def get_dynamodb_item(Table_Name,Resource,Title):
    get_table_item = dynamo.get_item(
        TableName=Table_Name,
        Key={
            'Resource': {'S': Resource},
            'Title': {'S': Title}
        }
    )
    return get_table_item